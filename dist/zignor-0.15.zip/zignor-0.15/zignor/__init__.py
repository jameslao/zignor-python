__all__ = ['randn', 'zignor', 'rnor']

from .zignor import randn, zignor, rnor
