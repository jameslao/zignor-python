__all__ = ['randn', 'zignor', 'rnor', 'rexp']

from .zignor import randn, zignor, rnor, rexp

__version__ = '0.1.7'
